function myFunction() {
  var x =
  document.getElementById("myLinks");
  if (x.style.display === "block") {
      x.style.display = "none";
  } else {
      x.style.display = "block";
  }
}
var preco = $(".preco")

$(".carrinho").each(function(i) {
  $(this).click(function(){
    var preco2 = prompt("Digite a quantidade desejada:")
    var totalpreco = preco2 * preco.eq(i).html()
    alert(totalpreco)
  })
})

