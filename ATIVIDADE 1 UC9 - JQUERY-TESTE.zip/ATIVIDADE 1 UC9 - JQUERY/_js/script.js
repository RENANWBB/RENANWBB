function myFunction() {
  var x =
  document.getElementById("myLinks");
  if (x.style.display === "block") {
      x.style.display = "none";
  } else {
      x.style.display = "block";
  }
}

function togglemenu() {
  if(document.querySelector('#menu').style.display == 'block'){
      document.querySelector('#menu').style.display = 'none'
  }else{
      document.querySelector('#menu').style.display = 'block'
  }
}

function comprar_pacote(){
  var nome = window.prompt("Porfavor informe seu nome antes da compra!")
  window.alert(`Compra efetuada com sucesso ${nome}, qualquer duvida entre na aba Sobre nós ou mande sua dúvida na aba contato!`);
}